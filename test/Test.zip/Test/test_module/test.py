class Test():
    
    def call(self):
        print("call")