from setuptools import setup, find_packages
 
 
 
setup(name='test',
      version='1.0', 
      url='.test_module',
      license='MIT',
      author='zudog',
      author_email='zudog@naver.com',
      description='test',
      zip_safe=False,
      setup_requires=[''])